#!/bin/sh

    jar.exe uf RecordEdit.jar net/sf/RecordEditor/utils/RecEdit.properties
    jar.exe uf LayoutEdit.jar net/sf/RecordEditor/utils/RecEdit.properties
