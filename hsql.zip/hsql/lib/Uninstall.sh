#! /bin/sh
    
    nohup C:\Program Files\Java\jre1.8.0_171/bin/java -jar "C:\Users\dilip\Desktop\hsql/Uninstaller/uninstaller.jar"

