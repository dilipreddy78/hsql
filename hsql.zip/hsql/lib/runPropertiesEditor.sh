#! /bin/sh

    libdir=C:\Users\dilip\Desktop\hsql/lib
    
    C:\Program Files\Java\jre1.8.0_171/bin/java -jar "${libdir}/run.jar" net.sf.RecordEditor.editProperties.EditOptions

 
