#! /bin/sh

    libdir=C:\Users\dilip\Desktop\hsql/lib
    javaCmd="C:\Program Files\Java\jre1.8.0_171/bin/java"

    ##cd /home/bruce/RecordEdit/HSQLDB/Database
    if [ "$1" = "hide" ]; then
    	if [ -f "${libdir}/hsqldbmain.jar" -a  -f "${libdir}/RecordEdit.jar" -a  -f "${libdir}/LayoutEdit.jar" -a -f "${libdir}/JRecord_Common.jar" -a -f "${libdir}/properties.zip" ] ; then
           nohup $javaCmd -cp "${libdir}/LayoutEdit.jar:${libdir}/hsqldbmain.jar:${libdir}/RecordEdit.jar:${libdir}/JRecord_Common.jar:${libdir}/properties.zip" net.sf.RecordEditor.layoutEd.ShutdownHSQLDB > /dev/null 2>&1
        fi
        exit 0
    else
       nohup $javaCmd -cp "${libdir}/LayoutEdit.jar:${libdir}/hsqldbmain.jar:${libdir}/RecordEdit.jar:${libdir}/JRecord_Common.jar:${libdir}/properties.zip" net.sf.RecordEditor.layoutEd.ShutdownHSQLDB
    fi

 
