#! /bin/sh
#
#  This script will
#  1) Establish the position of the DB directory (check the old position, if it exists use it)
#     Otherwise use the new location
#  2) extract the DB from the Zip file if it does no exist
#  3) Start the HSQL server  
#
    dbDir="C:\Users\dilip\Desktop\hsql/Database"
    javaCmd="C:\Program Files\Java\jre1.8.0_171/bin/java"
    libDir="C:\Users\dilip\Desktop\hsql/lib"
    if [ -f "$dbDir/recordedit.script" ]; then
	echo "HSQL DB $dbDir used."
    else
#	dbDir="${HOME}/.RecordEditor/HSQLDB/Database"
	dbDir="C:\Users\dilip/.RecordEditor/HSQLDB/Database"
	if [ -f "$dbDir/recordedit.script" ]; then
	    echo "HSQL DB $dbDir used."
	else
	    echo "Extracting Database to $dbDir"
	    $javaCmd -jar "${libDir}/run.jar" net.sf.RecordEditor.edit.XCreateData N $dbDir
    	fi    
    fi
    
    cd "${dbDir}"

    $javaCmd -cp "${libDir}/hsqldbmain.jar" org.hsqldb.Server

