#! /bin/sh

    'msgfmt --java -d . -r ReMsgs -l it ReMsgs_it.po'
