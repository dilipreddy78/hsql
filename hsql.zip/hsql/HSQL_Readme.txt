 RecordEditor 0.99.0 (License: GPL)
&==================================*

The RecordEditor is a Data File Editor (for both CSV (Comma / tab seperated fields)
and fixed field positions files typically used in Cobol / IBM Mainframe).
It uses Record-Layout to format a file in a human readable format. 
It can edit both Text and binary files in PC / Unix / IBM Mainframe formats.

The Record-Layouts are stored in a DB, but they can be imported from a Cobol Copybook
or Xml-file specification.


 Program License: GPL 2/3 or later
*---------------------------------*
### Changes 0.99

* Choice of 3 File open dialogs (2 have file preview)
* New File open dialog with Recent / Favourite files / directories
* Fixes for sort of large files - more work to do



### Changes 0.98.5

* Updates for JRecord 0.90
* Rename code gen template stdPojo to lineWrapperPojo
* add Xml Compare and Xml Directory compare

### Changes 0.98.4

* Two new CodeGen Templates added.
* Fix for Linux HSQL installer
* Fix for Generate from the file being editted

### Changes 0.98.3

* Can define Csv Quotes in hex format (Single byte character-set).
* Byte level parsers upgraded to handle Quotes.

### Changes 0.98.2
  
* Minor fixes, Including (hopefully) fixing field-list-scroll issue.
* Move the Numeric = next to the Text = in the find and filter screen.                                                 
* New CommitCount and FetchCount parameter options to improve performance with big Layouts</li>
* Enhanced python Code generation
* New Script (macro) functions to edit files.
* New Script functions to process multiple files

### Changes 0.98.1

* Add Python Fixed Width generate options

### Changes 0.98

* Added JRecord Code Generqation options (Generate) drop down menu

